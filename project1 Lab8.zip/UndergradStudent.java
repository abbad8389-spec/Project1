/**
 * Name: [Write your name here]
 * ID: [Write your 9-digit KKU ID here]
 * Issues: None
 * AI Usage: Claude (Anthropic AI) helped me design and write this code. I studied
 * every part of it and I can explain it without AI.
 */

/** Undergraduate student: the passing percentage is 60%. */
public class UndergradStudent extends Student {

    public UndergradStudent(String name, String id, int numCourses) {
        super(name, id, numCourses);   // reuse the parent constructor
    }

    @Override
    public double getPassingPercentage() { return 60.0; }

    @Override
    public String getType() { return "Undergraduate"; }
}
