/**
 * Name: [Write your name here]
 * ID: [Write your 9-digit KKU ID here]
 * Issues: None
 * AI Usage: Claude (Anthropic AI) helped me design and write this code. I studied
 * every part of it and I can explain it without AI.
 */

import java.util.ArrayList;

/**
 * Keeps and manages many students.
 * It only knows the parent type Student, so it works with undergraduate
 * and graduate students without any if/else (polymorphism).
 */
public class RegistrationSystem {

    private final ArrayList<Student> students = new ArrayList<>();

    // Adds a student; returns false if the KKU id already exists
    public boolean addStudent(Student s) {
        if (findById(s.getId()) != null) {
            return false;
        }
        students.add(s);
        return true;
    }

    // Returns the student with this id, or null if not found
    public Student findById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id.trim())) {
                return s;
            }
        }
        return null;
    }

    // Enters or modifies all marks of a student; false if student not found.
    // Throws IllegalArgumentException if the marks are not valid.
    public boolean enterMarks(String id, double[] marks) {
        Student s = findById(id);
        if (s == null) {
            return false;
        }
        s.setMarks(marks);
        return true;
    }

    public int getCount() {
        return students.size();
    }

    // Prints every student with the marks (toString of each object is used)
    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students registered yet.");
            return;
        }
        for (Student s : students) {
            System.out.println(s);
        }
        System.out.println("Total students: " + students.size());
    }
}
