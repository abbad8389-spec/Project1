/**
 * Name: [Write your name here]
 * ID: [Write your 9-digit KKU ID here]
 * Issues: None
 * AI Usage: Claude (Anthropic AI) helped me design and write this code. I studied
 * every part of it and I can explain it without AI.
 */

/**
 * Interface: a contract for anything that can be graded.
 * It says WHAT must be done, not HOW (abstraction).
 */
public interface Gradable {

    // The minimum percentage a student needs to pass a course
    double getPassingPercentage();

    // Decides if one mark is a pass or a fail
    boolean isPassed(double mark);
}
