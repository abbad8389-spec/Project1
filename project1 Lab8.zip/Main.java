/**
 * Name: [Write your name here]
 * ID: [Write your 9-digit KKU ID here]
 * Issues: None
 * AI Usage: Claude (Anthropic AI) helped me design and write this code. I studied
 * every part of it and I can explain it without AI.
 */

import java.util.NoSuchElementException;
import java.util.Scanner;

/** Shows the menu, reads the user input and calls RegistrationSystem. */
public class Main {

    private static final Scanner in = new Scanner(System.in);
    private static final RegistrationSystem system = new RegistrationSystem();

    public static void main(String[] args) {
        try {
            int choice;
            do {
                System.out.println("\nMenu:");
                System.out.println("1. Enter Student Details");
                System.out.println("2. Enter / Modify Marks");
                System.out.println("3. Display Marks Info.");
                System.out.println("4. Display Student Details");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                choice = readInt();

                switch (choice) {
                    case 1: enterStudentDetails(); break;
                    case 2: enterMarks(); break;
                    case 3: displayMarksInfo(); break;
                    case 4: system.displayAllStudents(); break;
                    case 5: System.out.println("Goodbye!"); break;
                    default: System.out.println("Invalid choice, try again.");
                }
            } while (choice != 5);
        } catch (NoSuchElementException e) {
            System.out.println("\nInput ended. Goodbye!");   // input stream closed
        }
    }

    // Option 1: asks for the level, name, id and number of courses
    private static void enterStudentDetails() {
        System.out.print("Student level (1 = Undergraduate, 2 = Graduate): ");
        int level = readInt();
        if (level != 1 && level != 2) {
            System.out.println("Error: level must be 1 or 2.");
            return;
        }
        System.out.print("Enter Student Name: ");
        String name = in.nextLine();
        System.out.print("Enter ID Number: ");
        String id = in.nextLine();
        System.out.print("How many courses last semester? ");
        int courses = readInt();

        try {
            // A Student variable can hold either child object (polymorphism)
            Student s = (level == 2) ? new GradStudent(name, id, courses)
                                     : new UndergradStudent(name, id, courses);
            if (system.addStudent(s)) {
                System.out.println("Student added: " + s.getName());
            } else {
                System.out.println("Error: this KKU ID already exists.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Option 2: enters the marks (or replaces them = modify), then shows them
    private static void enterMarks() {
        System.out.print("Enter Student ID: ");
        String id = in.nextLine();
        Student s = system.findById(id);
        if (s == null) {
            System.out.println("Error: student not found.");
            return;
        }
        // Keep asking until the marks are valid
        while (true) {
            System.out.print("Enter Marks for " + s.getNumCourses() + " subjects: ");
            try {
                String[] parts = in.nextLine().trim().split("\\s+");
                double[] marks = new double[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    marks[i] = Double.parseDouble(parts[i]);
                }
                system.enterMarks(id, marks);
                break;
            } catch (NumberFormatException e) {
                System.out.println("Error: please enter numbers only.");
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        // As in Project.1: show the marks info right after entering the marks
        System.out.print(s.getMarksInfo());
    }

    // Option 3: prints the marks info of one student
    private static void displayMarksInfo() {
        System.out.print("Enter Student ID: ");
        Student s = system.findById(in.nextLine());
        if (s == null) {
            System.out.println("Error: student not found.");
            return;
        }
        System.out.print(s.getMarksInfo());
    }

    // Reads an integer; returns -1 for wrong input instead of crashing
    private static int readInt() {
        try {
            return Integer.parseInt(in.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
