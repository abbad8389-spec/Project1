/**
 * Name: [Write your name here]
 * ID: [Write your 9-digit KKU ID here]
 * Issues: None
 * AI Usage: Claude (Anthropic AI) helped me design and write this code. I studied
 * every part of it and I can explain it without AI.
 */

/** Graduate student: the passing percentage is 80%. */
public class GradStudent extends Student {

    public GradStudent(String name, String id, int numCourses) {
        super(name, id, numCourses);
    }

    @Override
    public double getPassingPercentage() { return 80.0; }

    @Override
    public String getType() { return "Graduate"; }
}
