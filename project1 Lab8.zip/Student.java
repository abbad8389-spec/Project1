/**
 * Name: [Write your name here]
 * ID: [Write your 9-digit KKU ID here]
 * Issues: None
 * AI Usage: Claude (Anthropic AI) helped me design and write this code. I studied
 * every part of it and I can explain it without AI.
 */

/**
 * Abstract parent class for every student.
 * - Encapsulation: all fields are private and checked by setters/constructor.
 * - Abstraction: the passing percentage is left for the subclasses to define.
 * Data and rules come from Project.1 (name, KKU id, number of courses, marks).
 */
public abstract class Student implements Gradable {

    public static final int MAX_COURSES = 5;      // maximum courses allowed
    public static final double MAX_MARK = 100.0;  // highest possible mark

    private String name;
    private String id;
    private int numCourses;
    private double[] marks;                       // null until marks are entered

    // The constructor reuses the setters so validation always applies
    public Student(String name, String id, int numCourses) {
        setName(name);
        setId(id);
        setNumCourses(numCourses);
    }

    // ---------- Getters ----------
    public String getName() { return name; }
    public String getId() { return id; }
    public int getNumCourses() { return numCourses; }
    public boolean hasMarks() { return marks != null; }

    // ---------- Setters with validation ----------

    // Name is trimmed and converted to Title Case (john m doe -> John M Doe)
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        this.name = toTitleCase(name);
    }

    // KKU id must start with 4 and be made of exactly 9 digits
    public void setId(String id) {
        if (id == null || !id.trim().matches("4\\d{8}")) {
            throw new IllegalArgumentException(
                "KKU ID must start with 4 and be made of 9 digits.");
        }
        this.id = id.trim();
    }

    // Number of courses must be from 1 to MAX_COURSES
    private void setNumCourses(int numCourses) {
        if (numCourses < 1 || numCourses > MAX_COURSES) {
            throw new IllegalArgumentException(
                "Number of courses must be between 1 and " + MAX_COURSES + ".");
        }
        this.numCourses = numCourses;
    }

    // Used to enter marks the first time AND to modify them later
    public void setMarks(double[] newMarks) {
        if (newMarks == null || newMarks.length != numCourses) {
            throw new IllegalArgumentException(
                "You must enter exactly " + numCourses + " marks.");
        }
        for (double m : newMarks) {
            if (m < 0 || m > MAX_MARK) {
                throw new IllegalArgumentException(
                    "Each mark must be between 0 and 100.");
            }
        }
        this.marks = newMarks.clone();            // keep a private copy
    }

    // ---------- Calculations ----------
    public double getAverage() {
        double sum = 0;
        for (double m : marks) sum += m;
        return sum / marks.length;
    }

    public double getMax() {
        double max = marks[0];
        for (double m : marks) if (m > max) max = m;
        return max;
    }

    public double getMin() {
        double min = marks[0];
        for (double m : marks) if (m < min) min = m;
        return min;
    }

    // Written once here; each subclass supplies its own passing percentage
    @Override
    public boolean isPassed(double mark) {
        return mark >= getPassingPercentage();
    }

    // Each subclass tells what kind of student it is
    public abstract String getType();

    // ---------- Output ----------

    // Table of marks with Pass/Fail, average, max and min (as in Project.1)
    public String getMarksInfo() {
        if (!hasMarks()) {
            return "Marks have not been entered yet.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-8s%-8s%-6s%s%n", "Course", "Mark", "P/F",
                String.format("Avg: %.1f", getAverage())));
        sb.append("===========================").append(System.lineSeparator());
        double max = getMax();
        double min = getMin();
        for (int i = 0; i < marks.length; i++) {
            String label = "--";
            if (marks[i] == max) label = "Max";
            else if (marks[i] == min) label = "Min";
            sb.append(String.format("%-8d%-8s%-6s%s%n", i + 1, formatMark(marks[i]),
                    isPassed(marks[i]) ? "Pass" : "Fail", label));
        }
        return sb.toString();
    }

    // Student details followed by the marks
    @Override
    public String toString() {
        return "Name: " + name + System.lineSeparator()
             + "KKU ID: " + id + System.lineSeparator()
             + "Level: " + getType() + " (pass mark: "
             + formatMark(getPassingPercentage()) + "%)" + System.lineSeparator()
             + getMarksInfo();
    }

    // ---------- Helpers ----------
    private static String toTitleCase(String text) {
        String[] words = text.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(Character.toUpperCase(w.charAt(0)))
              .append(w.substring(1).toLowerCase());
        }
        return sb.toString();
    }

    // Prints 85.0 as 85 but keeps 85.5 as 85.5
    private static String formatMark(double m) {
        return m == Math.floor(m) ? String.valueOf((int) m) : String.valueOf(m);
    }
}
