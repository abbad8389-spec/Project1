import java.util.ArrayList;

/**
 * Manages many students. It only knows the parent type (Student),
 * so it works with undergrad and grad students without any if/else (polymorphism).
 */
public class RegistrationSystem {
    private final ArrayList<Student> students = new ArrayList<>();

    public boolean addStudent(Student s) {
        if (findById(s.getId()) != null) {
            return false;                 // duplicate ID not allowed
        }
        students.add(s);
        return true;
    }

    public Student findById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    public boolean updateMarks(String id, double newMarks) {
        Student s = findById(id);
        if (s == null) return false;
        s.setMarks(newMarks);             // may throw if marks are invalid
        return true;
    }

    public void displayAll() {
        if (students.isEmpty()) {
            System.out.println("No students registered yet.");
            return;
        }
        for (Student s : students) {
            System.out.println(s);        // calls each object's own toString/rules
        }
        long passed = students.stream().filter(Student::isPassed).count();
        System.out.println("Total: " + students.size()
                + " | Passed: " + passed
                + " | Failed: " + (students.size() - passed));
    }
}
