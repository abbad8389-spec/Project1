/**
 * Abstract parent class. Holds the data common to all students.
 * - Encapsulation: fields are private, accessed through getters/setters.
 * - Abstraction: getPassingPercentage() is left for the subclasses to define.
 */
public abstract class Student implements Gradable {
    public static final double MAX_MARKS = 100.0;

    private String name;
    private String id;
    private double marks;

    public Student(String name, String id, double marks) {
        this.name = name;
        this.id = id;
        setMarks(marks);          // reuse the setter so validation always applies
    }

    // ---------- Getters ----------
    public String getName() { return name; }
    public String getId()   { return id; }
    public double getMarks() { return marks; }

    // ---------- Setter with validation (encapsulation) ----------
    public void setMarks(double marks) {
        if (marks < 0 || marks > MAX_MARKS) {
            throw new IllegalArgumentException(
                "Marks must be between 0 and " + MAX_MARKS);
        }
        this.marks = marks;
    }

    // ---------- Gradable implementation ----------
    @Override
    public double getPercentage() {
        return (marks / MAX_MARKS) * 100;
    }

    @Override
    public boolean isPassed() {
        // Works for ANY subclass: it calls the subclass's own passing percentage
        return getPercentage() >= getPassingPercentage();
    }

    // Each student type must say what kind of student it is
    public abstract String getType();

    @Override
    public String toString() {
        return String.format("%-14s | ID: %-8s | %-12s | Marks: %6.2f | Needs: %4.0f%% | %s",
                name, id, getType(), marks, getPassingPercentage(),
                isPassed() ? "PASSED" : "FAILED");
    }
}
