/** Graduate student: passing percentage is 80%. */
public class GradStudent extends Student {
    public GradStudent(String name, String id, double marks) {
        super(name, id, marks);
    }

    @Override
    public double getPassingPercentage() { return 80.0; }

    @Override
    public String getType() { return "Graduate"; }
}
