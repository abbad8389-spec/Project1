/**
 * Interface: defines WHAT any gradable entity must be able to do,
 * without saying HOW (pure abstraction / contract).
 */
public interface Gradable {
    double getPassingPercentage();   // required percentage to pass
    double getPercentage();          // student's current percentage
    boolean isPassed();              // pass / fail decision
}
