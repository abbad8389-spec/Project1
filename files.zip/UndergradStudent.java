/** Undergraduate student: passing percentage is 60%. */
public class UndergradStudent extends Student {
    public UndergradStudent(String name, String id, double marks) {
        super(name, id, marks);   // call the parent constructor
    }

    @Override
    public double getPassingPercentage() { return 60.0; }

    @Override
    public String getType() { return "Undergrad"; }
}
