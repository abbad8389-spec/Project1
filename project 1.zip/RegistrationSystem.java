import java.util.ArrayList;

public class RegistrationSystem {
    private final ArrayList<Student> students = new ArrayList<>();

    public boolean addStudent(Student s) {
        if (findById(s.getId()) != null) {
            return false;
        }
        students.add(s);
        return true;
    }

    public Student findById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    public boolean updateMarks(String id, double newMarks) {
        Student s = findById(id);
        if (s == null) return false;
        s.setMarks(newMarks);
        return true;
    }

    public void displayAll() {
        if (students.isEmpty()) {
            System.out.println("No students registered yet.");
            return;
        }
        for (Student s : students) {
            System.out.println(s);
        }
        long passed = students.stream().filter(Student::isPassed).count();
        System.out.println("Total: " + students.size()
                + " | Passed: " + passed
                + " | Failed: " + (students.size() - passed));
    }
}
