public abstract class Student implements Gradable {
    public static final double MAX_MARKS = 100.0;

    private String name;
    private String id;
    private double marks;

    public Student(String name, String id, double marks) {
        this.name = name;
        this.id = id;
        setMarks(marks);
    }

    public String getName() { return name; }
    public String getId()   { return id; }
    public double getMarks() { return marks; }

    public void setMarks(double marks) {
        if (marks < 0 || marks > MAX_MARKS) {
            throw new IllegalArgumentException(
                "Marks must be between 0 and " + MAX_MARKS);
        }
        this.marks = marks;
    }

    @Override
    public double getPercentage() {
        return (marks / MAX_MARKS) * 100;
    }

    @Override
    public boolean isPassed() {
        return getPercentage() >= getPassingPercentage();
    }

    public abstract String getType();

    @Override
    public String toString() {
        return String.format("%-14s | ID: %-8s | %-12s | Marks: %6.2f | Needs: %4.0f%% | %s",
                name, id, getType(), marks, getPassingPercentage(),
                isPassed() ? "PASSED" : "FAILED");
    }
}
