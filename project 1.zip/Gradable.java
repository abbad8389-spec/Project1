public interface Gradable {
    double getPassingPercentage();
    double getPercentage();
    boolean isPassed();
}
