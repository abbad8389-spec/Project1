import java.util.Scanner;

public class Main {
    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        RegistrationSystem system = new RegistrationSystem();
        int choice;
        do {
            System.out.println("\n===== Registration System =====");
            System.out.println("1. Add undergraduate student");
            System.out.println("2. Add graduate student");
            System.out.println("3. Modify student marks");
            System.out.println("4. Display all students");
            System.out.println("5. Exit");
            System.out.print("Choice: ");
            choice = readInt();

            switch (choice) {
                case 1: addStudent(system, false); break;
                case 2: addStudent(system, true);  break;
                case 3: modifyMarks(system);       break;
                case 4: system.displayAll();       break;
                case 5: System.out.println("Goodbye!"); break;
                default: System.out.println("Invalid choice, try again.");
            }
        } while (choice != 5);
    }

    private static void addStudent(RegistrationSystem system, boolean grad) {
        System.out.print("Name: ");
        String name = in.nextLine().trim();
        System.out.print("ID: ");
        String id = in.nextLine().trim();
        System.out.print("Marks (0-100): ");
        double marks = readDouble();
        try {
            Student s = grad ? new GradStudent(name, id, marks)
                             : new UndergradStudent(name, id, marks);
            System.out.println(system.addStudent(s)
                    ? "Student added."
                    : "Error: this ID already exists.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void modifyMarks(RegistrationSystem system) {
        System.out.print("Student ID: ");
        String id = in.nextLine().trim();
        System.out.print("New marks (0-100): ");
        double marks = readDouble();
        try {
            System.out.println(system.updateMarks(id, marks)
                    ? "Marks updated."
                    : "Error: student not found.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static int readInt() {
        try { return Integer.parseInt(in.nextLine().trim()); }
        catch (NumberFormatException e) { return -1; }
    }
    private static double readDouble() {
        try { return Double.parseDouble(in.nextLine().trim()); }
        catch (NumberFormatException e) { return -1; }
    }
}
