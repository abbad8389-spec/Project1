public class UndergradStudent extends Student {
    public UndergradStudent(String name, String id, double marks) {
        super(name, id, marks);
    }

    @Override
    public double getPassingPercentage() { return 60.0; }

    @Override
    public String getType() { return "Undergrad"; }
}
